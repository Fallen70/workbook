# Exceptions

There are dedicated classes for handling exceptions in Python. When the program attempts an impossible action, it will raise an exception.
For example, trying to access a non-existent index or performing an addition on a `string`.

```python
import sys

def count_to(number):
    for n in range(1, number+1):
        print(n)

def main():
    stop = sys.argv[1]
    count_to(stop)

if name == "main":
    main()
```

If we run this code, we will get the following result:

```
$ python count.py 5
Traceback (most recent call last):
  File "/opt/git/python_onboarding/count.py", line 12, in
    main()
  File "/opt/git/python_onboarding/count.py", line 9, in main
    count_to(stop)
  File "/opt/git/python_onboarding/count.py", line 4, in count_to
    for n in range(1, number+1):
TypeError: can only concatenate str (not "int") to str
```
## Traceback 

When an error occurs in Python, it will display the error stack. Python `Traceback` are designed to be read starting from the end. In our example, the trace that interests us is as follows:

```
  File "/opt/git/python_onboarding/count.py", line 4, in count_to
    for n in range(1, number+1):
TypeError: can only concatenate str (not "int") to str
```

We are attempting to concatenate (using `+`) between a str and an int, which raises a TypeError exception.

To correct the error, we need to write:
```python
import sys

def count_to(number):
    for n in range(1, int(number)+1):
        print(n)

def main():
    stop = sys.argv[1]
    count_to(stop)

if __name__ == "__main__":
    main()
```
```
$ python count.py 5
1
2
3
4
5
````

## Handling an Exception

To handle exceptions, you can use the keywords `try`, `except`, and `finally`.

```python
try:
    2 / 0
except ZeroDivisionError as e:
    print( f"An error '{e}' occured")
```

You can either handle the error or propagate it using `raise`.

Everything below the `finally` keyword will always be executed, whether an exception occurred or not.

```python
def divide( a, x ):
    try:
        r = a / x
    except ZeroDivisionError as e:
        print( "Zero Division Error")
    finally:
        r = 1
    return r
```

This method will always return `1`.
           
```python
def divide( a, x ):
    try:
        return = a / x
    except ZeroDivisionError as e:
        print( "Zero Division Error")
    finally:
        return 1
```

## Common Types of Exceptions

 * **TypeError**: Occurs when an operation or function is applied to an object of an inappropriate type. This can happen, for example, if you try to perform an operation between two incompatible types.
 * **ValueError**: Occurs when a function receives an argument of the correct type but with an inappropriate value. This often happens during type conversions.
 * **KeyError**: Occurs when a requested key in a dictionary does not exist. This means you are trying to access a key that is not present.
 * **IndexError**: Occurs when you try to access an index of a list that is out of its range. This generally happens when the index is greater than the length of the list minus one.



## Raising or Propagating an Exception

To raise or propagate an exception, you simply use the raise keyword. Don't hesitate to use common types when they correspond to the encountered error.

```python

def divide( a, x ):
    try:
        a = int(a)
        x = int(x)
    except ValueError as e:
        raise TypeError( "Unable to cast int" ) from e 
    if x == 0:
        raise ValueError( "Cannot divide by Zero" )
    return a / x
```

## Creating an Exception

You simply need to create a class that inherits from the Exception class. Of course, you can also inherit from any classes that you have created.

```python
class MainCustomException(Exception):
  pass

class SubCustomException1(MainCustomException):
  pass

class SubCustomException2(MainCustomException):
  pass
```

## Going Further

### Be Careful Not to Be Too High in the Except

If you catch a high-level error, you will catch all the errors beneath it (see the hierarchy below).

This can cause problems because you may catch the `KeyboardInterrupt` exception and prevent `Ctrl+C` from working.

[example](../../example/exceptions/keyboard_interruption_catch.py)

### GroupedException

Introduced in Python 3.11, this class allows you to group exceptions of different types for later handling.

Python Documentation on Raising and Handling Multiple Unrelated Exceptions

### Exception Hierarchy

You can display the hierarchy of `Exceptions` by showing the help for the `builtins` module.

```python
import builtins
help(builtins)
Help on built-in module builtins:

NAME
    builtins - Built-in functions, exceptions, and other objects.

DESCRIPTION
    Noteworthy: None is the `nil' object; Ellipsis represents `...' in slices.

CLASSES
    object
        BaseException
            Exception
                ArithmeticError
                    FloatingPointError
                    OverflowError
                    ZeroDivisionError
                AssertionError
                AttributeError
                BufferError
                EOFError
                ImportError
                    ModuleNotFoundError
                LookupError
                    IndexError
                    KeyError
                MemoryError
                NameError
                    UnboundLocalError
                OSError
                    BlockingIOError
                    ChildProcessError
                    ConnectionError
                        BrokenPipeError
                        ConnectionAbortedError
                        ConnectionRefusedError
                        ConnectionResetError
                    FileExistsError
                    FileNotFoundError
                    InterruptedError
                    IsADirectoryError
                    NotADirectoryError
                    PermissionError
                    ProcessLookupError
                    TimeoutError
                ReferenceError
                RuntimeError
                    NotImplementedError
                    RecursionError
                StopAsyncIteration
                StopIteration
                SyntaxError
                    IndentationError
                        TabError
                SystemError
                TypeError
                ValueError
                    UnicodeError
                        UnicodeDecodeError
                        UnicodeEncodeError
                        UnicodeTranslateError
                Warning
                    BytesWarning
                    DeprecationWarning
                    EncodingWarning
                    FutureWarning
                    ImportWarning
                    PendingDeprecationWarning
                    ResourceWarning
                    RuntimeWarning
                    SyntaxWarning
                    UnicodeWarning
                    UserWarning
            GeneratorExit
            KeyboardInterrupt
            SystemExit
```
