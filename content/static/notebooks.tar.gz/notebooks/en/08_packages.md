# Module and Package

## Module

A Python file (.py) intended to be imported by other .py files. Importing a module executes the code contained in that module and provides access to a module object that stores the functions, classes, and other data of that module.

Variables defined in a module that are not inside a function or class are called global variables. The global variables of each module are accessible as attributes of the module object.

Python caches modules after they are imported, so importing the same module twice will return the same module object.

## Package

A Python module created from a directory (instead of a single .py file). Python packages are created by making a directory that contains a file named `__init__.py`. Python packages can contain sub-modules and sub-packages.

## How to Clear a Module's Cache

The module cache that Python uses is a feature, not a bug: Python does this for performance reasons. However, this feature can start to feel like a bug when we are testing our code from the Python REPL while making modifications.

The simplest way to resolve this issue is to exit the REPL and start a new one, which launches an entirely new Python process (with a brand new sys.modules dictionary). However, there are other ways to do this.

You can also try modifying sys.modules by removing items to clear the cache for that module:
```python
del sys.modules['points']
```
Or you could use the reload function from Python's importlib module, which reloads a module object:
```python
from importlib import reload
```
In both cases, you might not completely resolve your issue. Indeed, reloading a module does not remove references to the old versions of classes or instances of the old versions of classes. Therefore, the simplest way to truly resolve this problem is to exit the REPL and restart it.

### Import Rules
Avoid using complete imports of a module with `import *`, as this makes the code difficult to debug and maintain.

In some cases, you may encounter a situation where a module has the same name in two different packages. You can dynamically rename the imported module using the `as` keyword:

```python
from math import sqrt as msqrt
from cmath import sqrt as csqrt
msqrt(4)
csqrt(4)
```

# Project Structure

Here is an example of a package structure with a main package named app and a sub-package within it:

```
app/
├── app_module.py
├── __init__.py
└── sub_package1
    ├── __init__.py
    └── package.py
```

## Python path

Pour être en mesure d'importer quelquechose du package app il faut que le PYTHONPATH soit correct:

 * Soit python est exécuté dans le dossier qui contien le dossier app
 * Soit la variable PYTHONPATH doit contenir le chemin vers le dossier contenant app

**exemple:** si mon chemin est `/path/to/my/app`

## Python Path

In order to import something from the app package, the PYTHONPATH must be set correctly:

 * Either Python is executed from the directory that contains the app folder.
 * Or the PYTHONPATH variable must include the path to the directory containing app.

**Example**: If my path is `/path/to/my/app`

### using execution context

```bash
cd /path/to/my
python 
```

### setting PYTHONPATH

```bash
export PYTHONPATH=/path/to/my/
python
```

## import a module

```python
from app import app_module
```


# venv
Python allows you to create a virtual environment for package installation. This not only isolates the installation of packages but also does not affect the underlying Python installation, which remains common across environments.

Creating a virtual environment enables you to select a specific version of Python for that venv. This is particularly useful for managing dependencies and ensuring that projects have consistent environments.

## create a venv 

```shell
python -m venv venv
```

## activation

Activating the venv allows you to override the environment variables so that the binaries from the virtual environment take precedence over the default system binaries.

### Linux
```shell
source venv/bin/activate
```
### Windows
#### bat
```shell
venv\Script\activate.bat
```
#### powershell
```shell
.\venv\Script\Activate.ps1
```


## desactivation

It is possible to deactivate the venv to restore the environment variables to their original state.

### Linux
```shell
deactivate
```
### Windows
```shell
deactivate
```
## Adding Variables to the venv

The activate script can be modified to add environment variables accessible within the context of the venv.

To add a variable, simply place it at the end of this file.

### Linux
fin du script `venv/bin/activate`
```shell
export VARIABLE='TEST'
```
### Windows
#### bat
fin du script `venv\Script\activate.bat`
```shell
SET VARIABLE='TEST'
```
#### powershell
fin du script `venv\Script\Activate.ps1`
```shell
$env:VARIABLE='TEST'
```
To ensure that the variable is no longer usable once you exit the context of the venv, you need to add its removal in the `deactivate` method of the `activate` script, typically at the beginning of the file.

### Linux
deactivate du script `venv/bin/activate`
```shell
unset VARIABLE
```
### Windows
#### bat
deactivate du script `venv\Script\activate.bat`
```shell
SET VARIABLE=
```
#### powershell
deactivate du script `venv\Script\Activate.ps1`
```shell
Remove-Item env:VARIABLE
```

# Windows

## Dynamically Configure the PYTHONPATH for venv

https://medium.com/@HojjatA/how-to-set-the-pythonpath-for-your-virualenv-in-windows-2ab5bf596e15
