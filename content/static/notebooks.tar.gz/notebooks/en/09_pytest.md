# Pytest

[Pytest](https://docs.pytest.org/en/stable/) is a framework that facilitates writing unit tests in Python. It provides tools to make test writing easier. It also allows executing tests in the unit test format. Additionally, it enables the direct use of the assert keyword, which allows for much more readable tests.

## Discovery and Structure

Pytest performs test discovery; by default, it will scan all the files in the project to find files named `test_*.py` or `*_test.py`. From these files, it collects test items:

 * Test functions or methods prefixed with `test` that are outside of any class.
 * Test functions or methods prefixed with `test` inside test classes prefixed with `Test` (without an `__init__` method). Methods decorated with `@staticmethod` and `@classmethod` are also considered.

### Recommended Structure

```
src/
    mypkg/
        __init__.py
        app.py
        view.py
tests/
    conftest.py
    test_app.py
    test_view.py
    ...
```

[Documentation](https://docs.pytest.org/en/stable/explanation/goodpractices.html#test-discovery)

## Fixtures

[Documentation](https://docs.pytest.org/en/stable/explanation/fixtures.html#)

This tool allows you to write reusable elements for multiple tests. By default, there are already existing fixtures available that allow you to:

 * Capture logs, stdout, and stderr
 * Simulate temporary files or directories
 * Manage cache between test sessions

### Writing and Using Fixtures

You can create a fixture using the `pytest.fixture` decorator:

```python
import pytest


class Fruit:
    def __init__(self, name):
        self.name = name

    def __eq__(self, other):
        return self.name == other.name


@pytest.fixture
def my_fruit():
    return Fruit("apple")


@pytest.fixture
def fruit_basket(my_fruit):
    return [Fruit("banana"), my_fruit]


def test_my_fruit_in_basket(my_fruit, fruit_basket):
    assert my_fruit in fruit_basket
```

### Accessibility

Fixtures will be accessible in the module where they were defined. To make them accessible to all tests, you need to declare them in the conftest.py file. You can check all available fixtures using the command `pytest --fixtures`.

## Parameterized Tests

[Documentation](https://docs.pytest.org/en/stable/example/parametrize.html)

Parameterized tests allow for optimizing the writing of tests by parameterizing a set of tests.

```python
import pytest

def add( a, b):
    return a + b

testdata = [ (1,1,2),
             (1,2,3),
             (-10,0,-10),
             (0.5,0.5,1),
             ("a","b","ab"),
             ([1],[0],[1,0]),
           ]

@pytest.mark.parametrize("a,b,expected", testdata )
def test_add( a, b, expected ):
    assert add(a,b) == expected 
```

The advantage is that pytest will create a separate test for each tuple in the test data, allowing you to pinpoint exactly which value fails if the test were to fail.

## Catching Exceptions

By using pytest.raises, you can catch errors in your program.

```python
import pytest


def myfunc():
    raise ValueError("Exception 123 raised")


def test_match():
    with pytest.raises(ValueError, match=r".* 123 .*"):
        myfunc()
``` 

